"use client";

import React, { useState } from "react";
import { Box, Tabs, Tab, Typography } from "@mui/material";
import {
  AttachMoney,
  CreditCard,
  Receipt,
  TrendingUp,
} from "@mui/icons-material";

// Import revenue sub-components
import LeaseRevenueTab from "./revenue/LeaseRevenueTab";
import CreditCardsTab from "./revenue/CreditCardsTab";
import ChargesTab from "./revenue/ChargesTab";
import OtherRevenueTab from "./revenue/OtherRevenueTab";

export default function RevenueTab({ driverNumber, startDate, endDate, reportData }) {
  const [activeSubTab, setActiveSubTab] = useState(0);

  const handleSubTabChange = (event, newValue) => {  
    setActiveSubTab(newValue);
  };

  // If no reportData, show message
  if (!reportData) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography color="textSecondary">
          Generate a report to view revenue data
        </Typography>
      </Box>
    );
  }

  return (
    <Box>
      <Tabs
        value={activeSubTab}
        onChange={handleSubTabChange}
        sx={{ borderBottom: 1, borderColor: "divider", mb: 3 }}
      >
        <Tab 
          icon={<AttachMoney />} 
          iconPosition="start" 
          label={`Lease Revenue ($${reportData.leaseRevenue.total.toFixed(2)})`}
        />
        <Tab 
          icon={<CreditCard />} 
          iconPosition="start" 
          label={`Credit Cards ($${reportData.creditCardRevenue.total.toFixed(2)})`}
        />
        <Tab 
          icon={<Receipt />} 
          iconPosition="start" 
          label={`Charges ($${reportData.chargesRevenue.total.toFixed(2)})`}
        />
        <Tab 
          icon={<TrendingUp />} 
          iconPosition="start" 
          label="Other Revenue" 
        />
      </Tabs>

      {activeSubTab === 0 && (
        <LeaseRevenueTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
          data={reportData.leaseRevenue.data}
        />
      )}
      {activeSubTab === 1 && (
        <CreditCardsTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
          data={reportData.creditCardRevenue.data}
        />
      )}
      {activeSubTab === 2 && (
        <ChargesTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
          data={reportData.chargesRevenue.data}
        />
      )}
      {activeSubTab === 3 && (
        <OtherRevenueTab
          driverNumber={driverNumber}
          startDate={startDate}
          endDate={endDate}
          data={null}
        />
      )}
    </Box>
  );
}