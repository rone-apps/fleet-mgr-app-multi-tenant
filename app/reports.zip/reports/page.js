"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import GlobalNav from "../components/GlobalNav";
import {
  Box,
  Container,
  Typography,
  Button,
  Paper,
  Grid,
  TextField,
  Tabs,
  Tab,
  Autocomplete,
  Card,
  CardContent,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  CircularProgress,
} from "@mui/material";
import {
  Assessment,
  Download,
  TrendingUp,
  TrendingDown,
  Visibility,
  Print,
  Email,
  Close,
  AccountBalance,
  CheckCircle,
} from "@mui/icons-material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import axios from "axios";

// Import tab components
import RevenueTab from "./components/RevenueTab";
import ExpenseTab from "./components/ExpenseTab";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080/api";

export default function ReportsPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState(null);
  const [drivers, setDrivers] = useState([]);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  
  // ✅ Cached data for all revenue and expense types
  const [reportData, setReportData] = useState(null);
  
  // Dialog state
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);

  const getCurrentUser = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return null;

      const response = await axios.get(`${API_BASE_URL}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      return response.data;
    } catch (error) {
      console.error("Error getting current user:", error);
      return null;
    }
  };

  useEffect(() => {
    const checkAuth = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        router.push("/signin");
        return;
      }

      const user = await getCurrentUser();
      if (!user) {
        router.push("/signin");
        return;
      }

      setCurrentUser(user);
      fetchDrivers();
    };

    checkAuth();
  }, [router]);

  const fetchDrivers = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(`${API_BASE_URL}/drivers`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const allDrivers = response.data
        .sort((a, b) => {
          const nameA = `${a.firstName} ${a.lastName}`.toLowerCase();
          const nameB = `${b.firstName} ${b.lastName}`.toLowerCase();
          return nameA.localeCompare(nameB);
        });
      
      setDrivers(allDrivers);
    } catch (error) {
      console.error("Error fetching drivers:", error);
      setError("Failed to fetch drivers");
    }
  };

  // ✅ Fetch ALL data upfront and cache it
  const fetchAllReportData = async () => {
    if (!selectedDriver || !startDate || !endDate) return;

    setLoading(true);
    setError("");
    
    try {
      const token = localStorage.getItem("token");
      
      // Format dates to YYYY-MM-DD
      const formatDate = (date) => {
        const d = new Date(date);
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      };
      
      const formattedStartDate = formatDate(startDate);
      const formattedEndDate = formatDate(endDate);

      console.log('🚀 Fetching ALL report data for driver:', selectedDriver.driverNumber);

      // ✅ Fetch ALL revenue types in parallel
      const [leaseRevenueRes, creditCardRes, chargesRes] = await Promise.allSettled([
        // Lease Revenue
        axios.get(`${API_BASE_URL}/reports/lease-revenue`, {
          params: { 
            ownerDriverNumber: selectedDriver.driverNumber,
            startDate: formattedStartDate, 
            endDate: formattedEndDate 
          },
          headers: { Authorization: `Bearer ${token}` },
        }),
        // Credit Card Revenue
        axios.get(`${API_BASE_URL}/reports/credit-card-revenue`, {
          params: { 
            driverNumber: selectedDriver.driverNumber,
            startDate: formattedStartDate, 
            endDate: formattedEndDate 
          },
          headers: { Authorization: `Bearer ${token}` },
        }),
        // Charges Revenue
        axios.get(`${API_BASE_URL}/reports/charges-revenue`, {
          params: { 
            driverNumber: selectedDriver.driverNumber,
            startDate: formattedStartDate, 
            endDate: formattedEndDate 
          },
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      // ✅ Fetch ALL expense types in parallel
      const [fixedExpensesRes] = await Promise.allSettled([
        // Fixed Expenses (includes recurring + one-time)
        axios.get(`${API_BASE_URL}/reports/fixed-expenses`, {
          params: { 
            driverNumber: selectedDriver.driverNumber,
            startDate: formattedStartDate, 
            endDate: formattedEndDate 
          },
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      // ✅ Extract data from successful responses
      const leaseRevenue = leaseRevenueRes.status === 'fulfilled' ? leaseRevenueRes.value.data : { totalRevenue: 0, shifts: [] };
      const creditCardRevenue = creditCardRes.status === 'fulfilled' ? creditCardRes.value.data : { totalAmount: 0, transactions: [] };
      const chargesRevenue = chargesRes.status === 'fulfilled' ? chargesRes.value.data : { totalAmount: 0, charges: [] };
      const fixedExpenses = fixedExpensesRes.status === 'fulfilled' ? fixedExpensesRes.value.data : { totalExpenses: 0, expenses: [] };

      console.log('✅ Lease Revenue:', leaseRevenue.totalRevenue);
      console.log('✅ Credit Card Revenue:', creditCardRevenue.totalAmount);
      console.log('✅ Charges Revenue:', chargesRevenue.totalAmount);
      console.log('✅ Fixed Expenses:', fixedExpenses.totalExpenses);

      // ✅ Calculate totals
      const totalRevenue = 
        parseFloat(leaseRevenue.totalRevenue || 0) +
        parseFloat(creditCardRevenue.totalAmount || 0) +
        parseFloat(chargesRevenue.totalAmount || 0);

      const totalExpenses = parseFloat(fixedExpenses.totalExpenses || 0);

      const netAmount = totalRevenue - totalExpenses;
      const amountDue = netAmount > 0 ? netAmount : 0;

      console.log('📊 TOTALS:');
      console.log('Total Revenue:', totalRevenue);
      console.log('Total Expenses:', totalExpenses);
      console.log('Amount Due:', amountDue);

      // ✅ Store everything in cache
      const data = {
        // Revenue data
        leaseRevenue: {
          total: parseFloat(leaseRevenue.totalRevenue || 0),
          data: leaseRevenue
        },
        creditCardRevenue: {
          total: parseFloat(creditCardRevenue.totalAmount || 0),
          data: creditCardRevenue
        },
        chargesRevenue: {
          total: parseFloat(chargesRevenue.totalAmount || 0),
          data: chargesRevenue
        },
        // Expense data
        fixedExpenses: {
          total: parseFloat(fixedExpenses.totalExpenses || 0),
          data: fixedExpenses
        },
        // Totals
        totalRevenue,
        totalExpenses,
        amountPaid: 0, // TODO: Integrate payment tracking
        amountDue,
      };

      setReportData(data);

    } catch (error) {
      console.error("Error fetching report data:", error);
      setError(`Failed to fetch report data: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = () => {
    if (!selectedDriver || !startDate || !endDate) {
      setError("Please select a driver and date range");
      return;
    }
    setError("");
    setReportData(null); // Clear old data
    fetchAllReportData();
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleOpenDetails = () => {
    setDetailsDialogOpen(true);
  };

  const handleCloseDetails = () => {
    setDetailsDialogOpen(false);
  };

  const handleDownload = () => {
    console.log("Download report");
  };

  const handlePrint = () => {
    window.print();
  };

  const handleEmail = () => {
    console.log("Email report");
  };

  const isReportReady = reportData !== null;

  if (!currentUser) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh" }}>
        <Typography>Loading...</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ minHeight: "100vh", backgroundColor: "#f6f9fc" }}>
      <GlobalNav currentUser={currentUser} />
      
      <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
        {/* Header */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" sx={{ fontWeight: 700, color: "#3e5244", mb: 1 }}>
            <Assessment sx={{ mr: 1, verticalAlign: "middle", fontSize: 32 }} />
            Financial Reports
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Generate detailed revenue and expense reports for drivers
          </Typography>
        </Box>

        {/* Filter Controls */}
        <Paper sx={{ p: 3, mb: 3 }}>
          <Typography variant="h6" sx={{ mb: 3, fontWeight: 600 }}>
            Report Parameters
          </Typography>

          {error && (
            <Box sx={{ mb: 2 }}>
              <Typography color="error">{error}</Typography>
            </Box>
          )}

          <Grid container spacing={2}>
            <Grid item xs={12} md={3}>
              <Autocomplete
                options={drivers}
                getOptionLabel={(option) => 
                  `${option.firstName} ${option.lastName} (${option.driverNumber})`
                }
                value={selectedDriver}
                onChange={(event, newValue) => {
                  setSelectedDriver(newValue);
                }}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Search Driver"
                    placeholder="Type to search..."
                  />
                )}
                isOptionEqualToValue={(option, value) => 
                  option.driverNumber === value.driverNumber
                }
                noOptionsText="No drivers found"
              />
            </Grid>

            <Grid item xs={12} md={3}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Start Date"
                  value={startDate}
                  onChange={(newValue) => setStartDate(newValue)}
                  slotProps={{ textField: { fullWidth: true } }}
                />
              </LocalizationProvider>
            </Grid>

            <Grid item xs={12} md={3}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="End Date"
                  value={endDate}
                  onChange={(newValue) => setEndDate(newValue)}
                  slotProps={{ textField: { fullWidth: true } }}
                />
              </LocalizationProvider>
            </Grid>

            <Grid item xs={12} md={3}>
              <Button
                variant="contained"
                fullWidth
                onClick={handleGenerateReport}
                disabled={!selectedDriver || !startDate || !endDate || loading}
                startIcon={loading ? <CircularProgress size={20} /> : <Assessment />}
                sx={{ 
                  height: 56,
                  backgroundColor: "#3e5244",
                  "&:hover": { backgroundColor: "#2d3d32" }
                }}
              >
                {loading ? "Loading..." : "Generate Report"}
              </Button>
            </Grid>
          </Grid>
        </Paper>

        {/* Summary Cards Strip */}
        {isReportReady && (
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6} md={2.4}>
              <Card sx={{ height: '100%', bgcolor: '#e8f5e9' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <TrendingUp sx={{ color: '#2e7d32', mr: 1 }} />
                    <Typography variant="caption" color="textSecondary">
                      Total Revenue
                    </Typography>
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#2e7d32' }}>
                    ${reportData.totalRevenue.toFixed(2)}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={2.4}>
              <Card sx={{ height: '100%', bgcolor: '#ffebee' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <TrendingDown sx={{ color: '#c62828', mr: 1 }} />
                    <Typography variant="caption" color="textSecondary">
                      Total Expenses
                    </Typography>
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#c62828' }}>
                    ${reportData.totalExpenses.toFixed(2)}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={2.4}>
              <Card sx={{ height: '100%', bgcolor: '#e3f2fd' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <CheckCircle sx={{ color: '#1565c0', mr: 1 }} />
                    <Typography variant="caption" color="textSecondary">
                      Amount Paid
                    </Typography>
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#1565c0' }}>
                    ${reportData.amountPaid.toFixed(2)}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={2.4}>
              <Card sx={{ height: '100%', bgcolor: '#fff3e0' }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <AccountBalance sx={{ color: '#e65100', mr: 1 }} />
                    <Typography variant="caption" color="textSecondary">
                      Amount Due
                    </Typography>
                  </Box>
                  <Typography variant="h5" sx={{ fontWeight: 700, color: '#e65100' }}>
                    ${reportData.amountDue.toFixed(2)}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} sm={6} md={2.4}>
              <Card 
                sx={{ 
                  height: '100%', 
                  bgcolor: '#3e5244',
                  cursor: 'pointer',
                  '&:hover': { bgcolor: '#2d3d32' }
                }}
                onClick={handleOpenDetails}
              >
                <CardContent sx={{ 
                  display: 'flex', 
                  flexDirection: 'column', 
                  justifyContent: 'center',
                  alignItems: 'center',
                  height: '100%'
                }}>
                  <Visibility sx={{ color: 'white', fontSize: 32, mb: 1 }} />
                  <Typography variant="button" sx={{ color: 'white', fontWeight: 600 }}>
                    See Details
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}

        {/* Report Tabs */}
        {isReportReady && (
          <Paper sx={{ mb: 3 }}>
            <Tabs
              value={activeTab}
              onChange={handleTabChange}
              sx={{ borderBottom: 1, borderColor: "divider" }}
            >
              <Tab
                icon={<TrendingUp />}
                iconPosition="start"
                label="Revenue"
                sx={{ minHeight: 64 }}
              />
              <Tab
                icon={<TrendingDown />}
                iconPosition="start"
                label="Expenses"
                sx={{ minHeight: 64 }}
              />
            </Tabs>

            <Box sx={{ p: 3 }}>
              {activeTab === 0 && (
                <RevenueTab
                  driverNumber={selectedDriver?.driverNumber}
                  startDate={startDate}
                  endDate={endDate}
                  reportData={reportData}
                />
              )}
              {activeTab === 1 && (
                <ExpenseTab
                  driverNumber={selectedDriver?.driverNumber}
                  startDate={startDate}
                  endDate={endDate}
                  reportData={reportData}
                />
              )}
            </Box>
          </Paper>
        )}

        {/* Empty State */}
        {!isReportReady && !loading && (
          <Paper sx={{ p: 6, textAlign: "center" }}>
            <Assessment sx={{ fontSize: 80, color: "#3e5244", opacity: 0.3, mb: 2 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom sx={{ fontWeight: 600 }}>
              Select Parameters to Generate Reports
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Choose a driver and date range to view financial reports
            </Typography>
          </Paper>
        )}

        {/* Loading State */}
        {loading && (
          <Paper sx={{ p: 6, textAlign: "center" }}>
            <CircularProgress size={60} sx={{ mb: 2 }} />
            <Typography variant="h6" color="text.secondary">
              Loading financial data...
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Fetching revenue and expense information
            </Typography>
          </Paper>
        )}
      </Container>

      {/* Detailed Report Dialog */}
      <Dialog 
        open={detailsDialogOpen} 
        onClose={handleCloseDetails}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700 }}>
              Financial Report - {selectedDriver?.firstName} {selectedDriver?.lastName}
            </Typography>
            <IconButton onClick={handleCloseDetails}>
              <Close />
            </IconButton>
          </Box>
          <Typography variant="body2" color="textSecondary">
            Period: {startDate?.toLocaleDateString()} - {endDate?.toLocaleDateString()}
          </Typography>
        </DialogTitle>

        <DialogContent dividers>
          {reportData && (
            <>
              {/* Summary Section */}
              <Box sx={{ mb: 4 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Summary
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                      <Typography variant="caption" color="textSecondary">
                        Total Revenue
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#2e7d32' }}>
                        ${reportData.totalRevenue.toFixed(2)}
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                      <Typography variant="caption" color="textSecondary">
                        Total Expenses
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#c62828' }}>
                        ${reportData.totalExpenses.toFixed(2)}
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                      <Typography variant="caption" color="textSecondary">
                        Amount Paid
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#1565c0' }}>
                        ${reportData.amountPaid.toFixed(2)}
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper sx={{ p: 2, bgcolor: '#f5f5f5' }}>
                      <Typography variant="caption" color="textSecondary">
                        Amount Due
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 700, color: '#e65100' }}>
                        ${reportData.amountDue.toFixed(2)}
                      </Typography>
                    </Paper>
                  </Grid>
                </Grid>
              </Box>

              <Divider sx={{ my: 3 }} />

              {/* Revenue Breakdown */}
              <Box sx={{ mb: 4 }}>
                <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
                  Revenue Breakdown
                </Typography>
                <TableContainer component={Paper} variant="outlined">
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Source</TableCell>
                        <TableCell align="right">Amount</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      <TableRow>
                        <TableCell>Lease Revenue</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                          ${reportData.leaseRevenue.total.toFixed(2)}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Credit Card Revenue</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                          ${reportData.creditCardRevenue.total.toFixed(2)}
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>Account Charges</TableCell>
                        <TableCell align="right" sx={{ fontWeight: 600 }}>
                          ${reportData.chargesRevenue.total.toFixed(2)}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </TableContainer>
              </Box>

              <Divider sx={{ my: 3 }} />

              {/* Net Summary */}
              <Box sx={{ p: 3, bgcolor: '#f5f5f5', borderRadius: 2 }}>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="textSecondary">
                      Net Income (Revenue - Expenses)
                    </Typography>
                  </Grid>
                  <Grid item xs={6} sx={{ textAlign: 'right' }}>
                    <Typography variant="h6" sx={{ fontWeight: 700 }}>
                      ${(reportData.totalRevenue - reportData.totalExpenses).toFixed(2)}
                    </Typography>
                  </Grid>
                </Grid>
              </Box>
            </>
          )}
        </DialogContent>

        <DialogActions sx={{ p: 2, gap: 1 }}>
          <Button
            startIcon={<Download />}
            variant="outlined"
            onClick={handleDownload}
          >
            Download PDF
          </Button>
          <Button
            startIcon={<Print />}
            variant="outlined"
            onClick={handlePrint}
          >
            Print
          </Button>
          <Button
            startIcon={<Email />}
            variant="outlined"
            onClick={handleEmail}
          >
            Email
          </Button>
          <Button
            variant="contained"
            onClick={handleCloseDetails}
            sx={{ 
              backgroundColor: "#3e5244",
              "&:hover": { backgroundColor: "#2d3d32" }
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}